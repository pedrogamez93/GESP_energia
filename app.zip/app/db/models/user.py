# app/db/models/user.py
from .identity import AspNetUser as User