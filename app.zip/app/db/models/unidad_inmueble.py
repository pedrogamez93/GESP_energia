# app/db/models/unidad_inmueble.py
# Re-exporta la clase ya definida en unidad.py para mantener compatibilidad de imports.
from .unidad import UnidadInmueble  # noqa: F401